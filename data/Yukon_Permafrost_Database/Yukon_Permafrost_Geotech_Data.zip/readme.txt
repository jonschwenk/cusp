Empty files indicate no publicly available data in that table. Export performed on 2025-09-21
